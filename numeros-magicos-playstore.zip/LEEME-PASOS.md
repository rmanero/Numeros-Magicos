# Números Mágicos → Google Play: guía de pasos

Qué hay en esta carpeta:

- `app/` proyecto Capacitor con el juego (`www/index.html`), configuración e imágenes de origen (`resources/`).
- `store/` todo lo que pide la ficha de Play: icono 512, imagen destacada 1024×500, 8 capturas 1080×1920, textos (`listing-es.md`) y política de privacidad (`privacidad.html`).

Lo que NO puedo hacer desde aquí (no hay Android ni red): compilar el `.aab` y subirlo. Se hace en tu ordenador con los pasos de abajo.

## 0. Cosas que tienes que rellenar tú

1. **Nombre de desarrollador** y **email de contacto**: sustituye `[NOMBRE DEL DESARROLLADOR]` y `[TU EMAIL DE CONTACTO]` en `store/privacidad.html` y `store/listing-es.md`.
2. **Identificador de la app** (`appId`) en `app/capacitor.config.json`. Ahora es `es.numerosmagicos.academia`. Cámbialo por uno tuyo y único (por ejemplo `es.tunombre.numerosmagicos`). **No se puede cambiar después de publicar.**
3. **Alojar la política de privacidad en una URL pública** (Play la exige). Lo más fácil: subir `privacidad.html` a GitHub Pages o a Netlify Drop (app.netlify.com/drop) y copiar la dirección.

## 1. Instalar herramientas (una vez)

- Node.js (versión LTS actual): nodejs.org
- Android Studio: developer.android.com/studio (incluye Java y el SDK de Android)

## 2. Crear el proyecto Android

En una terminal, dentro de la carpeta `app/`:

```
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli @capacitor/assets
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
npx cap open android
```

`capacitor-assets` genera los iconos (incluido el adaptable) y la pantalla de arranque a partir de `resources/`.

## 3. Probar en un móvil Android

1. En el móvil: Ajustes → Acerca del teléfono → pulsa 7 veces «Número de compilación» → activa «Depuración por USB».
2. Conecta el móvil por cable y, en Android Studio, pulsa ▶ (Run).
3. Juega una partida entera: arrastrar números, teclado numérico, sonido, guardar y cerrar la app, volver a abrirla (el progreso debe seguir).

Opcional: para fijar la orientación vertical, en `android/app/src/main/AndroidManifest.xml` añade `android:screenOrientation="portrait"` a la etiqueta `<activity>`.

## 4. Versión y firma

1. En `android/app/build.gradle` comprueba `versionCode 1` y `versionName "1.0.0"`. En cada actualización sube `versionCode` (2, 3…).
2. Comprueba que `targetSdkVersion` cumple lo que exige Google Play en ese momento (aparece en Play Console al subir el paquete; las plantillas actuales de Capacitor suelen cumplirlo).
3. En Android Studio: **Build → Generate Signed App Bundle / APK → Android App Bundle**. Crea un almacén de claves nuevo (*keystore*) y **guárdalo con copia de seguridad y apunta las contraseñas**. Si lo pierdes, no podrás actualizar la app con la misma clave de subida.
4. El resultado es un `.aab` (en `android/app/release/`).

## 5. Play Console

1. Crea la cuenta en play.google.com/console (pago único de unos 25 $ y verificación de identidad).
2. **Crear app** → nombre «Academia de Números Mágicos», idioma español, tipo **Juego**, **gratuita**.
3. Activa **Play App Signing** al subir el primer `.aab`.
4. Ficha principal (Crecimiento → Presencia en la tienda): copia los textos de `store/listing-es.md`; sube `store/icon-512.png`, `store/feature-graphic-1024x500.png` y las capturas de `store/screenshots/` (mínimo 2 para móvil, recomendado 4–8).
5. Si tu cuenta de desarrollador es personal y nueva, Google pide antes una **prueba cerrada** con unos 12 testers durante 14 días. Comprueba el requisito vigente en Play Console. Sube el `.aab` a «Pruebas cerradas», añade los emails de los testers y que lo instalen desde el enlace.
6. Cuando se pueda, crea una versión de **Producción** con el mismo `.aab`.

## 6. Respuestas a los formularios («Contenido de la app»)

| Formulario | Respuesta |
|---|---|
| Política de privacidad | La URL donde alojaste `privacidad.html` |
| Anuncios | No contiene anuncios |
| Acceso a la app | Sin restricciones (no hay inicio de sesión) |
| Público objetivo | Rangos 5-8 y 9-12 años. Al incluir menores de 13, se aplica la política de Familias |
| Atractivo para niños | Sí. No incluye anuncios ni compras, así que lo cumple |
| Clasificación de contenido | Cuestionario IARC: categoría «Referencia, noticias o educativo» o «Juego». Sin violencia, sexo, drogas, juego de azar, ni interacción entre usuarios, ni ubicación compartida |
| Seguridad de los datos | No recopila ni comparte datos. Todo se guarda en el dispositivo. Sin cifrado necesario en tránsito (no hay envío) |
| Aplicación de noticias, salud, finanzas, gobierno | No |
| ID de publicidad | No lo usa |
| Categoría | Educación |

Nota: la plantilla de Capacitor declara el permiso `INTERNET`. La app no lo usa; es un permiso normal que no requiere revisión especial.

## 7. Cómo actualizar el juego más adelante

1. Sustituye `app/www/index.html` por la versión nueva.
2. `npx cap sync android`
3. Sube `versionCode` en `build.gradle`, genera otro `.aab` y súbelo a Play Console.

## Qué conviene saber

- La tipografía redondeada (Fredoka) no va incluida: la app usa la fuente del sistema de cada móvil, así que el aspecto puede variar un poco entre dispositivos.
- El progreso se guarda en el móvil (en el almacenamiento interno de la app). Si se desinstala, se pierde.
- Las capturas son de la propia app, con datos de ejemplo. Puedes sustituirlas por capturas reales de tu móvil si lo prefieres.
