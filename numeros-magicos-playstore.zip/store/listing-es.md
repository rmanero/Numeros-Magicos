# Ficha de Google Play (español)

## Título (máx. 30 caracteres)
Academia de Números Mágicos

## Descripción breve (máx. 80 caracteres)
Sumas, restas, tablas y divisiones jugando con el dragón Chispa. ¡Sin anuncios!

## Descripción completa (máx. 4000 caracteres)
¡Bienvenida a la Academia de los Números Mágicos! 🐉✨

Acompaña a Chispa, un dragón simpático, y conviértete en una gran maga (o un gran mago) de los números. Una aventura de matemáticas para niños y niñas de 6 a 9 años, pensada para jugar sin ayuda de un adulto.

🗺️ CINCO MUNDOS PARA EXPLORAR
• Reino de las Sumas
• Bosque de las Restas
• Montaña de las Multiplicaciones
• Castillo de las Divisiones
• Isla de los Problemas

Cada mundo tiene 10 niveles, de fácil a gran desafío. Los niveles nuevos se abren cuando se demuestra que se dominan los anteriores, no solo por jugar.

🎮 NO ES UN SIMPLE TEST DE PREGUNTAS
• Elegir entre cuatro respuestas
• Escribir el resultado
• Arrastrar números a su sitio
• Encontrar el número que falta
• Resolver pequeños problemas con dibujos: caramelos, cromos, cumpleaños, excursiones…

💡 SI SE FALLA, SE APRENDE
Chispa anima, da una pista y deja volver a intentarlo. Si hace falta, explica la solución paso a paso con dibujos (por ejemplo, 24 × 3 es lo mismo que 24 + 24 + 24) y propone otra operación parecida para practicar.

⭐ RECOMPENSAS EN CADA PARTIDA
Estrellas, monedas mágicas, rachas de aciertos, cofres sorpresa, regalo diario e insignias. Con las monedas se pueden conseguir sombreros, coronas, gafas, capas y colores nuevos para Chispa.

📊 PANEL DE PROGRESO PARA LA FAMILIA
Operaciones realizadas, porcentaje de aciertos, nivel de cada mundo, tablas de multiplicar que domina, operaciones que más le cuestan y tiempo de juego.

🔒 SEGURO PARA NIÑOS
• Sin anuncios ni compras dentro de la app
• Sin registro ni cuentas
• No recoge ni comparte datos personales
• Funciona sin conexión a Internet
• El progreso se guarda solo en el dispositivo

Descarga la Academia de los Números Mágicos y convierte las matemáticas en una aventura.

## Categoría
Educación

## Etiquetas sugeridas
Matemáticas, Educación, Juegos educativos, Niños

## Notas de la versión 1.0
¡Primera versión! Cinco mundos, 50 niveles, explicaciones paso a paso, recompensas y panel de progreso.

## Datos de contacto (obligatorio el email)
Email: [TU EMAIL DE CONTACTO]
Política de privacidad: [URL donde publiques privacidad.html]
